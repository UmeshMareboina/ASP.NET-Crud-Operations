﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace CrudOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection scon;

            scon =new SqlConnection(ConfigurationManager.ConnectionStrings["scon"].ConnectionString);
            scon.Open();
            try
            {
                Console.WriteLine("Connection Established Successfully");
                string ans;
                do
                {
                    Console.WriteLine("Select from the options:");
                    Console.WriteLine("1.Insert");
                    Console.WriteLine("2.Select");
                    Console.WriteLine("3.Update");
                    Console.WriteLine("4.Delete");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch(choice)
                    {
                        case 1:
                            Console.WriteLine("Enter Student Id:");
                            int student_Id = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Enter Student Name:");
                            string student_name=Console.ReadLine();

                            Console.WriteLine("Enter Student Age:");
                            int student_age=Convert.ToInt32(Console.ReadLine());

                            //string insertQuery= "INSERT INTO StudentDetails (stu_name,stu_age) VALUES ('" + stu_name +"'," + stu_age +")";
                            string insertQuery = "SET IDENTITY_INSERT Student ON INSERT INTO Student(stu_Id,stu_name,stu_age) VALUES (" + student_Id + ",'" + student_name+ "','" + student_age + "') SET IDENTITY_INSERT Student OFF";
                            SqlCommand cmd =new SqlCommand(insertQuery);
                            Console.WriteLine("Data Inserted");
                            break;
                        case 2:

                            string displayQuery = "SELECT * FROM StudentDetails";
                            SqlCommand cmd2= new SqlCommand(displayQuery,scon);
                            SqlDataReader reader = cmd2.ExecuteReader();
                            while (reader.Read())
                            {
                                Console.WriteLine("Student Id: "+reader.GetString(0).ToString());
                                Console.WriteLine("Student Name: "+reader.GetValue(1).ToString());
                                Console.WriteLine("Student Age: "+reader.GetValue(2).ToString());
                            }
                            reader.Close();
                            break;
                        case 3:

                            int stu_id;
                            int stu_age;
                            Console.WriteLine("Enter Student Id to Update:");
                            stu_id = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter Student age to Update:");
                            stu_age = Convert.ToInt32(Console.ReadLine());
                            string updateQuery = "UPDATE StudentDetails SET stu_age =" + stu_id + "WHERE student_id =" + stu_age + "";
                            SqlCommand cmd3= new SqlCommand(updateQuery,scon);
                            cmd3.ExecuteNonQuery();
                            Console.WriteLine("Data Updated");
                            break;
                         case 4:
                            int s_id;
                            Console.WriteLine("Enter Student Id to Delete:");
                            s_id = Convert.ToInt32(Console.ReadLine());
                            string deleteQuery = "DELETE FROM StudentDetails WHERE stu_id= " + s_id;
                            SqlCommand cmd4= new SqlCommand(deleteQuery,scon);
                            cmd4.ExecuteNonQuery();
                            Console.WriteLine("Data Deleted");
                            break;
                            default:
                            Console.WriteLine("You Entered Wrong Option...");
                            break;

                    }
                    Console.WriteLine("Do you want to Continue:");
                    ans = Console.ReadLine();
               }while(ans != "N");                  // yes or no
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                scon.Close();
            }
        }
    }
}
