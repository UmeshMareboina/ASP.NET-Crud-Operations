﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace CrudConn
{
    internal class Program
    {
        static void Main(string[] args)
        {                                                                  // Connection to database

                SqlConnection conn; 
                conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlcon"].ConnectionString);
                conn.Open();
                Console.WriteLine("Connection Established Successfully");
                try
                {
                string message ;
                    do
                    {
                    Console.WriteLine("Select a options:");
                    Console.WriteLine("1.Insert");
                    Console.WriteLine("2.Select");
                    Console.WriteLine("3.Update");
                    Console.WriteLine("4.Delete");
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                            case 1:                                                                      // Create Operation
                                Console.WriteLine("Enter Student Id:");
                                int stu_id = Convert.ToInt32(Console.ReadLine());
                              
                                Console.WriteLine("Enter Student First Name:");
                                string stu_firstname = Console.ReadLine();

                                Console.WriteLine("Enter Student Last Name:");
                                string stu_lastname = Console.ReadLine();

                                Console.WriteLine("Enter Student Email:");
                                string stu_email = Console.ReadLine();

                            Console.WriteLine("Enter Department Id:");
                            int dept_id = Convert.ToInt32(Console.ReadLine());


                            string insertquery = "INSERT INTO stud_details(StuId,StuFirstName,StuLastName,StuEmail,dep_id) VALUES (" + stu_id + ",'" + stu_firstname + "','" + stu_lastname + "','" + stu_email + "'," + dept_id + ")";


                                SqlCommand insertconn = new SqlCommand(insertquery, conn);
                                insertconn.ExecuteNonQuery();
                                Console.WriteLine("Data Inserted");
                                break;
                            case 2:                                                                  // Read Operation
                                string retrive = "select *from stud_details";
                                SqlCommand retriveconn = new SqlCommand(retrive, conn);
                                SqlDataReader cmd2 = retriveconn.ExecuteReader();
                                while (cmd2.Read())
                                {
                                    int studid = Convert.ToInt32(cmd2["StuId"]);
                                    string stufirstname = Convert.ToString(cmd2["StuFirstName"]);
                                    string stulastname = Convert.ToString(cmd2["StuLastName"]);
                                    string stuemail = Convert.ToString(cmd2["StuEmail"]);
                                    int deptid = Convert.ToInt32(cmd2["dep_id"]);

                                Console.WriteLine(studid + " " + stufirstname + " " + stulastname + " " + stuemail+" "+ deptid);
                                }
                                //cmd2.Close();
                                break;
                            case 3:                                                                     // Update Operation
                                Console.WriteLine("Enter Student id For update :");
                                int stud_id = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Enter Student department id to Update:");
                            int depta_id = Convert.ToInt32(Console.ReadLine());


                            string updatequery = "UPDATE stud_details SET dept_id = ' " + depta_id + " ' WHERE stu_id = " + stud_id + "";
                            
                            SqlCommand updateconn = new SqlCommand(updatequery, conn);
                                updateconn.ExecuteNonQuery();
                                Console.WriteLine("Data is Sucessfully Updated in to a table :");
                                break;
                            case 4:                                                                      // Delete Operation
                                Console.WriteLine("Enter Student Id to delete student details :");
                                int stuid = Convert.ToInt32(Console.ReadLine());

                                string deletequery = "DELETE FROM stud_details where stuid=" + stuid;

                                SqlCommand cmd4 = new SqlCommand(deletequery, conn);
                                cmd4.ExecuteNonQuery();
                                Console.WriteLine("Data is Sucessfully delete in a table");
                                break;
                            default:
                                Console.WriteLine("Invalid Input :");
                                break;
                        }
                    Console.WriteLine("Do you want to Continue:(y/n)");

                    message = Console.ReadLine();

                } 
                while (message != "n");                  // yes or no
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            Console.ReadKey();
            }

        }
    }
